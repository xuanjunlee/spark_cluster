echo build hadoop images


docker build -t="spark" .
